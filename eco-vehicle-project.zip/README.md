# Eco Vehicle Project Demo Site

This is the demo and subscription platform for the Eco Vehicle Project.

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) to view the site

## Deployment

This project is configured for deployment on Netlify. The `netlify.toml` file contains all necessary configuration.

To deploy:
1. Push your changes to GitHub
2. Connect your repository to Netlify
3. Netlify will automatically build and deploy your site

## Security

This project implements several security measures:
- Strict Content Security Policy
- HTTPS enforcement
- XSS protection
- Frame protection
- Other security headers

## Environment Variables

Create a `.env.local` file with the following variables:
```
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=your_stripe_key
STRIPE_SECRET_KEY=your_stripe_secret
```

## Features

- Modern, responsive design
- Subscription system integration
- Security best practices
- Analytics ready
- SEO optimized

## Contributing

1. Create a feature branch
2. Make your changes
3. Submit a pull request
