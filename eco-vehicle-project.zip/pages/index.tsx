import { useState, useEffect } from 'react';
import Meta from '../components/Meta';
import Navigation from '../components/Navigation';
import ScrollProgress from '../components/ScrollProgress';
import CarConfigurator from '../components/CarConfigurator';
import Timeline from '../components/Timeline';
import ParticleBackground from '../components/ParticleBackground';
import ComparisonSlider from '../components/ComparisonSlider';
import StatsCounter from '../components/StatsCounter';
import ThemeSwitcher from '../components/ThemeSwitcher';
import LoadingSpinner from '../components/LoadingSpinner';
import Hero from '../components/Hero';
import Features from '../components/Features';
import Specs from '../components/Specs';
import Gallery from '../components/Gallery';
import PricingPlans from '../components/PricingPlans';

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => setIsLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {isLoading && <LoadingSpinner />}
      <div className="min-h-screen bg-white relative">
      <ScrollProgress />
      <Navigation />
      <Meta 
        title="Eco Vehicle - The Future of Sustainable Transport"
        description="Experience our revolutionary eco-vehicle platform combining cutting-edge technology with environmental responsibility."
      />
      
      <main>
        <ParticleBackground />
        <Hero />
        <Features />
        <StatsCounter />
        <CarConfigurator />
        <ComparisonSlider
          beforeImage="/images/car-traditional.jpg"
          afterImage="/images/car-eco.jpg"
          beforeLabel="Traditional Vehicle"
          afterLabel="Eco Vehicle"
        />
        <Timeline />
        <Specs />
        <Gallery />
        <PricingPlans />
        <ThemeSwitcher />
      </main>

      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-300">
            © {new Date().getFullYear()} Eco Vehicle. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
    </>
  );
}
