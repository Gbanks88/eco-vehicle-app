import { motion } from 'framer-motion';
import { IconType } from 'react-icons';
import { FaLeaf, FaChartLine, FaCog, FaShieldAlt, FaCloud, FaMobile } from 'react-icons/fa';

interface FeatureCardProps {
  title: string;
  description: string;
  icon: IconType;
  delay: number;
}

const FeatureCard = ({ title, description, icon: Icon, delay }: FeatureCardProps) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay }}
    viewport={{ once: true }}
    className="bg-white rounded-xl shadow-xl p-6 hover:shadow-2xl transition-shadow"
  >
    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
      <Icon className="w-6 h-6 text-green-600" />
    </div>
    <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </motion.div>
);

const features = [
  {
    icon: FaLeaf,
    title: 'Eco-Friendly Design',
    description: 'Zero emissions with sustainable materials and renewable energy integration.',
  },
  {
    icon: FaChartLine,
    title: 'Performance Analytics',
    description: 'Real-time monitoring and predictive maintenance using AI technology.',
  },
  {
    icon: FaCog,
    title: 'Smart Systems',
    description: 'Advanced autonomous capabilities and intelligent navigation.',
  },
  {
    icon: FaShieldAlt,
    title: 'Enhanced Safety',
    description: 'State-of-the-art safety features with predictive hazard detection.',
  },
  {
    icon: FaCloud,
    title: 'Cloud Integration',
    description: 'Seamless connectivity with cloud-based services and updates.',
  },
  {
    icon: FaMobile,
    title: 'Mobile Control',
    description: 'Complete vehicle control and monitoring from your smartphone.',
  },
];

export default function Features() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
            className="text-4xl font-bold text-gray-900 mb-4"
          >
            Revolutionary Features
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            viewport={{ once: true }}
            className="text-xl text-gray-600 max-w-2xl mx-auto"
          >
            Experience the next generation of sustainable transportation with our cutting-edge technology.
          </motion.p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={feature.title}
              {...feature}
              delay={0.2 + index * 0.1}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
