import { motion } from 'framer-motion';

const specs = [
  {
    category: 'Performance',
    items: [
      { label: 'Range', value: '500+ miles' },
      { label: 'Acceleration', value: '0-60 mph in 3.5s' },
      { label: 'Top Speed', value: '155 mph' },
      { label: 'Power Output', value: '450 kW' },
    ],
  },
  {
    category: 'Efficiency',
    items: [
      { label: 'Energy Consumption', value: '15 kWh/100mi' },
      { label: 'Charging Speed', value: '350 kW' },
      { label: 'Solar Integration', value: '25% boost' },
      { label: 'Regenerative Braking', value: '85% efficient' },
    ],
  },
  {
    category: 'Technology',
    items: [
      { label: 'Autonomous Level', value: 'Level 4' },
      { label: 'Connectivity', value: '5G enabled' },
      { label: 'Software Updates', value: 'Over-the-air' },
      { label: 'AI Integration', value: 'Advanced' },
    ],
  },
];

export default function Specs() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Technical Specifications
          </h2>
          <p className="text-xl text-gray-600">
            Leading the industry with revolutionary eco-friendly technology
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {specs.map((category, categoryIndex) => (
            <motion.div
              key={category.category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: categoryIndex * 0.1 }}
              viewport={{ once: true }}
              className="bg-gray-50 rounded-xl p-6"
            >
              <h3 className="text-2xl font-semibold text-gray-900 mb-6">
                {category.category}
              </h3>
              <div className="space-y-4">
                {category.items.map((item, itemIndex) => (
                  <motion.div
                    key={item.label}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: (categoryIndex * 0.1) + (itemIndex * 0.1) }}
                    viewport={{ once: true }}
                    className="flex justify-between items-center"
                  >
                    <span className="text-gray-600">{item.label}</span>
                    <span className="font-semibold text-gray-900">{item.value}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
