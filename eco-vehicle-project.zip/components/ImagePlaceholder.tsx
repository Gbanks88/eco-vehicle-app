import { useEffect, useRef } from 'react';

interface ImagePlaceholderProps {
  width: number;
  height: number;
  text: string;
  bgColor?: string;
  textColor?: string;
}

export default function ImagePlaceholder({ width, height, text, bgColor = '#1e40af', textColor = '#ffffff' }: ImagePlaceholderProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set background
    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, width, height);

    // Add text
    ctx.fillStyle = textColor;
    ctx.font = 'bold 24px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, width / 2, height / 2);

    // Add a simple car outline
    ctx.strokeStyle = textColor;
    ctx.lineWidth = 2;
    
    // Car body
    const centerX = width / 2;
    const centerY = height / 2;
    const carWidth = Math.min(width, height) * 0.4;
    const carHeight = carWidth * 0.5;

    ctx.beginPath();
    ctx.moveTo(centerX - carWidth/2, centerY + carHeight/4);
    ctx.lineTo(centerX - carWidth/3, centerY - carHeight/4);
    ctx.lineTo(centerX + carWidth/3, centerY - carHeight/4);
    ctx.lineTo(centerX + carWidth/2, centerY + carHeight/4);
    ctx.closePath();
    ctx.stroke();

    // Wheels
    const wheelRadius = carWidth * 0.1;
    ctx.beginPath();
    ctx.arc(centerX - carWidth/3, centerY + carHeight/3, wheelRadius, 0, Math.PI * 2);
    ctx.arc(centerX + carWidth/3, centerY + carHeight/3, wheelRadius, 0, Math.PI * 2);
    ctx.stroke();
  }, [width, height, text, bgColor, textColor]);

  return <canvas ref={canvasRef} width={width} height={height} />;
}
