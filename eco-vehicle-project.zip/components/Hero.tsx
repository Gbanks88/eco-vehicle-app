import dynamic from 'next/dynamic';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PresentationControls } from '@react-three/drei';

const EcoVehicleModel = dynamic(() => import('./EcoVehicleModel'), { ssr: false });

export default function Hero() {

  return (
    <div className="relative w-full h-screen">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-50 to-green-50">
        <Canvas camera={{ position: [4, 2, 4], fov: 45 }}>
          <color attach="background" args={['#f8fafc']} />
          <PresentationControls
            global
            rotation={[0, -0.3, 0]}
            polar={[-0.4, 0.2]}
            azimuth={[-1, 0.75]}
          >
            <group position-y={-0.75} dispose={null}>
              <EcoVehicleModel />
            </group>
          </PresentationControls>
          <Environment preset="city" />
          <OrbitControls enableZoom={false} />
        </Canvas>
      </div>
      <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-transparent to-white/80">
        <div className="text-center max-w-4xl px-4">
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6">
            The Future of
            <span className="block text-green-600">Sustainable Transport</span>
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8">
            Experience our revolutionary eco-vehicle platform combining cutting-edge technology
            with environmental responsibility.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-colors">
              Explore Features
            </button>
            <button className="bg-white text-green-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-50 transition-colors border-2 border-green-600">
              Watch Demo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
