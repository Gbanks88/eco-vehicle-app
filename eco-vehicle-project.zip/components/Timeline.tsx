import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';

const timelineEvents = [
  {
    year: '2023',
    title: 'Concept Unveiled',
    description: 'Revolutionary eco-vehicle concept introduced to the world.',
    icon: '🚗',
  },
  {
    year: '2024',
    title: 'Prototype Testing',
    description: 'Successful completion of rigorous testing phases.',
    icon: '🔧',
  },
  {
    year: '2025',
    title: 'Production Begins',
    description: 'Start of sustainable production at our eco-friendly facility.',
    icon: '🏭',
  },
  {
    year: '2026',
    title: 'Global Launch',
    description: 'Worldwide availability and expansion of charging network.',
    icon: '🌍',
  },
];

export default function Timeline() {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Our Journey
          </h2>
          <p className="text-xl text-gray-600">
            From concept to reality
          </p>
        </motion.div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-1/2 transform -translate-x-px h-full w-0.5 bg-gray-200" />

          {/* Timeline Events */}
          <div className="relative">
            {timelineEvents.map((event, index) => {
              const isEven = index % 2 === 0;
              return (
                <TimelineEvent
                  key={event.year}
                  event={event}
                  isEven={isEven}
                  index={index}
                />
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

function TimelineEvent({ event, isEven, index }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: isEven ? -50 : 50 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.5, delay: index * 0.2 }}
      className={`relative mb-16 ${isEven ? 'md:ml-auto md:pl-8' : 'md:mr-auto md:pr-8'} md:w-1/2`}
    >
      {/* Event Content */}
      <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
        <div className="flex items-center mb-4">
          <span className="text-3xl mr-4">{event.icon}</span>
          <div>
            <div className="font-bold text-green-600">{event.year}</div>
            <h3 className="text-xl font-semibold text-gray-900">{event.title}</h3>
          </div>
        </div>
        <p className="text-gray-600">{event.description}</p>
      </div>

      {/* Timeline Dot */}
      <div className="absolute top-6 md:top-8 left-1/2 transform -translate-x-1/2 md:translate-x-0 md:left-auto md:right-0 w-4 h-4">
        <div className="w-4 h-4 bg-green-500 rounded-full" />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-green-100 rounded-full animate-ping" />
      </div>
    </motion.div>
  );
}
