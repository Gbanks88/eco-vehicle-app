import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FiSun, FiMoon } from 'react-icons/fi';

const themes = {
  light: {
    primary: '#16a34a',
    secondary: '#1e40af',
    background: '#ffffff',
    text: '#1f2937',
  },
  dark: {
    primary: '#22c55e',
    secondary: '#3b82f6',
    background: '#0f172a',
    text: '#f3f4f6',
  },
};

export default function ThemeSwitcher() {
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const root = document.documentElement;
    const theme = isDark ? themes.dark : themes.light;

    Object.entries(theme).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value);
    });
  }, [isDark]);

  return (
    <motion.button
      initial={{ scale: 0 }}
      animate={{ scale: 1 }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      onClick={() => setIsDark(!isDark)}
      className="fixed bottom-6 right-6 z-50 bg-white dark:bg-gray-800 rounded-full p-3 shadow-lg"
    >
      {isDark ? (
        <FiSun className="w-6 h-6 text-yellow-500" />
      ) : (
        <FiMoon className="w-6 h-6 text-gray-700" />
      )}
    </motion.button>
  );
}
