import { useState } from 'react';
import { motion } from 'framer-motion';
// Simple color picker using native input
import { FiChevronRight, FiChevronLeft } from 'react-icons/fi';

const configOptions = {
  colors: [
    { name: 'Ocean Blue', hex: '#1e40af' },
    { name: 'Forest Green', hex: '#16a34a' },
    { name: 'Solar Red', hex: '#dc2626' },
    { name: 'Cosmic Black', hex: '#111827' },
    { name: 'Pearl White', hex: '#f8fafc' },
  ],
  wheels: [
    { name: 'Aero', efficiency: '+5%' },
    { name: 'Sport', efficiency: '+2%' },
    { name: 'Performance', efficiency: 'Standard' },
  ],
  interior: [
    { name: 'Eco Fabric', sustainability: '100%' },
    { name: 'Recycled Leather', sustainability: '95%' },
    { name: 'Premium Synthetic', sustainability: '90%' },
  ],
};

export default function CarConfigurator() {
  const [activeTab, setActiveTab] = useState('color');
  const [selectedColor, setSelectedColor] = useState(configOptions.colors[0]);
  const [selectedWheel, setSelectedWheel] = useState(configOptions.wheels[0]);
  const [selectedInterior, setSelectedInterior] = useState(configOptions.interior[0]);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [customColor, setCustomColor] = useState('#1e40af');

  const tabs = [
    { id: 'color', label: 'Exterior Color' },
    { id: 'wheels', label: 'Wheels' },
    { id: 'interior', label: 'Interior' },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Customize Your Vehicle
          </h2>
          <p className="text-xl text-gray-600">
            Create your perfect eco-friendly ride
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 3D Preview */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-lg p-6 aspect-video relative">
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                animate={{ rotateY: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="w-full h-full"
              >
                {/* This will be replaced by the 3D model */}
                <div 
                  className="w-full h-full rounded-lg transition-colors duration-500"
                  style={{ backgroundColor: activeTab === 'color' ? (showColorPicker ? customColor : selectedColor.hex) : '#1e40af' }}
                />
              </motion.div>
            </div>
            
            {/* Navigation Arrows */}
            <button className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 hover:bg-white transition-colors">
              <FiChevronLeft className="w-6 h-6" />
            </button>
            <button className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 rounded-full p-2 hover:bg-white transition-colors">
              <FiChevronRight className="w-6 h-6" />
            </button>
          </div>

          {/* Configuration Panel */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            {/* Tabs */}
            <div className="flex space-x-4 mb-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-green-100 text-green-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Color Options */}
            {activeTab === 'color' && (
              <div className="space-y-4">
                <div className="grid grid-cols-5 gap-3">
                  {configOptions.colors.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color)}
                      className={`w-full aspect-square rounded-full border-2 transition-transform hover:scale-110 ${
                        selectedColor.name === color.name ? 'border-green-500 scale-110' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: color.hex }}
                    />
                  ))}
                </div>
                <button
                  onClick={() => setShowColorPicker(!showColorPicker)}
                  className="w-full py-2 mt-4 bg-gray-100 rounded-lg text-gray-700 hover:bg-gray-200 transition-colors"
                >
                  {showColorPicker ? 'Hide Custom Color' : 'Custom Color'}
                </button>
                {showColorPicker && (
                  <div className="mt-4">
                    <input
                      type="color"
                      value={customColor}
                      onChange={(e) => setCustomColor(e.target.value)}
                      className="w-full h-12 rounded-lg cursor-pointer"
                    />
                  </div>
                )}
              </div>
            )}

            {/* Wheel Options */}
            {activeTab === 'wheels' && (
              <div className="space-y-3">
                {configOptions.wheels.map((wheel) => (
                  <button
                    key={wheel.name}
                    onClick={() => setSelectedWheel(wheel)}
                    className={`w-full p-4 rounded-lg text-left transition-colors ${
                      selectedWheel.name === wheel.name
                        ? 'bg-green-100 text-green-700'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    <div className="font-medium">{wheel.name}</div>
                    <div className="text-sm opacity-75">
                      Efficiency: {wheel.efficiency}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Interior Options */}
            {activeTab === 'interior' && (
              <div className="space-y-3">
                {configOptions.interior.map((interior) => (
                  <button
                    key={interior.name}
                    onClick={() => setSelectedInterior(interior)}
                    className={`w-full p-4 rounded-lg text-left transition-colors ${
                      selectedInterior.name === interior.name
                        ? 'bg-green-100 text-green-700'
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    <div className="font-medium">{interior.name}</div>
                    <div className="text-sm opacity-75">
                      Sustainability: {interior.sustainability}
                    </div>
                  </button>
                ))}
              </div>
            )}

            {/* Summary */}
            <div className="mt-6 pt-6 border-t">
              <div className="text-sm text-gray-600 space-y-2">
                <div className="flex justify-between">
                  <span>Color:</span>
                  <span className="font-medium">{showColorPicker ? 'Custom' : selectedColor.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Wheels:</span>
                  <span className="font-medium">{selectedWheel.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Interior:</span>
                  <span className="font-medium">{selectedInterior.name}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
