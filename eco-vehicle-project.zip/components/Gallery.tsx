import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import dynamic from 'next/dynamic';

const ImagePlaceholder = dynamic(() => import('./ImagePlaceholder'), { ssr: false });

const images = [
  {
    src: '/images/exterior-front.jpg',
    alt: 'Eco Vehicle Front View',
    title: 'Aerodynamic Design',
  },
  {
    src: '/images/interior-dashboard.jpg',
    alt: 'Smart Dashboard',
    title: 'Intelligent Cockpit',
  },
  {
    src: '/images/charging-station.jpg',
    alt: 'Charging Station',
    title: 'Fast Charging',
  },
  {
    src: '/images/solar-panels.jpg',
    alt: 'Solar Integration',
    title: 'Solar Technology',
  },
];

export default function Gallery() {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            Experience Innovation
          </h2>
          <p className="text-xl text-gray-300">
            Discover the beauty of sustainable engineering
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {images.map((image, index) => (
            <motion.div
              key={image.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="relative group cursor-pointer"
              onClick={() => setSelectedImage(index)}
            >
              <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden bg-blue-900">
                <ImagePlaceholder
                  width={1280}
                  height={720}
                  text={image.title}
                  bgColor="#1e40af"
                  textColor="#ffffff"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-2xl font-semibold text-white">{image.title}</h3>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <AnimatePresence>
          {selectedImage !== null && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedImage(null)}
            >
              <motion.div
                initial={{ scale: 0.9 }}
                animate={{ scale: 1 }}
                exit={{ scale: 0.9 }}
                className="relative max-w-6xl w-full aspect-video bg-blue-900 rounded-xl overflow-hidden"
              >
                <ImagePlaceholder
                  width={1920}
                  height={1080}
                  text={images[selectedImage].title}
                  bgColor="#1e40af"
                  textColor="#ffffff"
                />
              </motion.div>
              <button
                className="absolute top-4 right-4 text-white text-4xl"
                onClick={() => setSelectedImage(null)}
              >
                ×
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
