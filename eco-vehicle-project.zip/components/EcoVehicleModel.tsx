import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Mesh } from 'three';

export default function EcoVehicleModel() {
  const meshRef = useRef<Mesh>(null);
  const [hovered, setHovered] = useState(false);
  const [clicked, setClicked] = useState(false);

  useFrame((state, delta) => {
    if (meshRef.current) {
      // Smooth rotation
      meshRef.current.rotation.y += delta * (hovered ? 0.5 : 0.2);
      
      // Hover effect
      meshRef.current.scale.x = THREE.MathUtils.lerp(
        meshRef.current.scale.x,
        hovered ? 1.1 : 1,
        0.1
      );
      meshRef.current.scale.y = THREE.MathUtils.lerp(
        meshRef.current.scale.y,
        hovered ? 1.1 : 1,
        0.1
      );
      meshRef.current.scale.z = THREE.MathUtils.lerp(
        meshRef.current.scale.z,
        hovered ? 1.1 : 1,
        0.1
      );
    }
  });

  return (
    <group>
      {/* Car Body */}
      <mesh 
        ref={meshRef} 
        position={[0, 0.5, 0]}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onClick={() => setClicked(!clicked)}>
        <meshPhysicalMaterial
          color="#2563eb"
          metalness={0.6}
          roughness={0.2}
          clearcoat={0.8}
          clearcoatRoughness={0.2}
        />
        {/* Main body */}
        <group>
          <mesh position={[0, 0.4, 0]}>
            <capsuleGeometry args={[0.8, 2, 4, 16]} />
          </mesh>
          {/* Hood */}
          <mesh position={[0, 0.3, -1.2]}>
            <boxGeometry args={[1.6, 0.2, 0.8]} />
          </mesh>
          {/* Roof */}
          <mesh position={[0, 0.8, 0.3]}>
            <boxGeometry args={[1.5, 0.6, 1.8]} />
          </mesh>
        </group>
      </mesh>

      {/* Wheels */}
      {[[-0.8, -0.3, 0.8], [0.8, -0.3, 0.8], [-0.8, -0.3, -0.8], [0.8, -0.3, -0.8]].map(
        (position, index) => (
          <mesh key={index} position={new THREE.Vector3(...position)}>
            <cylinderGeometry args={[0.3, 0.3, 0.2, 32]} />
            <primitive object={new THREE.Euler(Math.PI / 2, 0, 0)} attach="rotation" />
            <meshPhysicalMaterial
              color="#1f2937"
              metalness={0.8}
              roughness={0.5}
            />
          </mesh>
        )
      )}

      {/* Windows */}
      <mesh position={[0, 1, 0]}>
        <boxGeometry args={[1.4, 0.5, 1.6]} />
        <meshPhysicalMaterial
          color="#a5f3fc"
          metalness={0.9}
          roughness={0.1}
          transparent
          opacity={0.3}
        />
      </mesh>

      {/* Solar Panel Roof */}
      <mesh position={[0, 1.3, 0]}>
        <boxGeometry args={[1.3, 0.05, 1.5]} />
        <meshPhysicalMaterial
          color="#0c4a6e"
          metalness={0.7}
          roughness={0.3}
        />
      </mesh>
    </group>
  );
}
