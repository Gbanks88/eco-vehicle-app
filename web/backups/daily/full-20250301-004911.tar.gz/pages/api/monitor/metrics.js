import fs from 'fs';
import path from 'path';

const LOG_DIR = path.join(process.cwd(), 'logs');
const METRICS_DIR = path.join(LOG_DIR, 'metrics');
const ALERTS_DIR = path.join(LOG_DIR, 'alerts');

function parseMetricsFile(filename) {
  try {
    const content = fs.readFileSync(filename, 'utf-8');
    const lines = content.trim().split('\n');
    const headers = lines[0].split(',');
    const latestData = lines[lines.length - 1].split(',');
    
    const metrics = {};
    headers.forEach((header, index) => {
      metrics[header] = latestData[index];
    });
    
    return metrics;
  } catch (error) {
    console.error(`Error parsing metrics file ${filename}:`, error);
    return null;
  }
}

function getLatestAlerts() {
  try {
    const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
    const alertFiles = fs.readdirSync(ALERTS_DIR)
      .filter(file => file.startsWith(today))
      .sort()
      .reverse();
    
    const alerts = [];
    for (const file of alertFiles.slice(0, 5)) { // Get last 5 alert files
      const content = fs.readFileSync(path.join(ALERTS_DIR, file), 'utf-8');
      const fileAlerts = content.trim().split('\n')
        .map(line => {
          const [timestamp, domain, message] = line.match(/\[(.*?)\] (.*?): (.*)/).slice(1);
          return {
            time: timestamp,
            domain: domain,
            message: message,
            severity: message.toLowerCase().includes('critical') ? 'critical' :
                     message.toLowerCase().includes('warning') ? 'warning' : 'info'
          };
        });
      alerts.push(...fileAlerts);
    }
    
    return alerts.slice(0, 10); // Return last 10 alerts
  } catch (error) {
    console.error('Error reading alerts:', error);
    return [];
  }
}

function calculateMetrics(domain, rawMetrics) {
  if (!rawMetrics) return null;

  const responseTime = parseFloat(rawMetrics.response_time) * 1000;
  const sslDays = parseInt(rawMetrics.ssl_days_remaining);
  const securityScore = parseInt(rawMetrics.security_score);
  
  return {
    name: domain,
    metrics: {
      status: securityScore > 90 ? 'healthy' :
              securityScore > 70 ? 'warning' : 'critical',
      responseTime: Math.round(responseTime),
      responseTimeStatus: responseTime < 1000 ? 'healthy' :
                         responseTime < 2000 ? 'warning' : 'critical',
      responseTimeTrend: -5, // Mock trend data
      sslDays: sslDays,
      sslStatus: sslDays > 30 ? 'healthy' :
                 sslDays > 14 ? 'warning' : 'critical',
      securityScore: securityScore,
      securityStatus: securityScore > 90 ? 'healthy' :
                     securityScore > 70 ? 'warning' : 'critical',
      chart: {
        labels: ['1h ago', '45m ago', '30m ago', '15m ago', 'now'],
        datasets: [{
          label: 'Response Time (ms)',
          data: [responseTime - 100, responseTime - 50, responseTime - 25, responseTime - 10, responseTime],
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1
        }]
      }
    }
  };
}

export default function handler(req, res) {
  try {
    // Read domain configuration
    const configPath = path.join(process.cwd(), 'scripts', 'monitor-config.json');
    const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
    
    // Get metrics for each domain
    const domains = Object.keys(config.domains)
      .map(domain => {
        const metricsFile = path.join(METRICS_DIR, `${domain.replace(/\//g, '_')}_${new Date().toISOString().split('T')[0].replace(/-/g, '')}.csv`);
        const rawMetrics = parseMetricsFile(metricsFile);
        return calculateMetrics(domain, rawMetrics);
      })
      .filter(Boolean);
    
    // Get recent alerts
    const alerts = getLatestAlerts();
    
    res.status(200).json({
      domains,
      alerts,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error in metrics API:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
}
